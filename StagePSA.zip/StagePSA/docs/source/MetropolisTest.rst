MetropolisTest module
=====================

.. automodule:: MetropolisTest
    :members:
    :undoc-members:
    :show-inheritance:
