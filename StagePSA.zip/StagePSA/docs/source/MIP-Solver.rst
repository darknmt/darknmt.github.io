MIP-Solver module
=================

This is my attemp to write a Mixed-Integer-Programming Solver. As I have not completed
this part, the documentation may not appeared clear and well-organized.

Please see `My Notebook <https://darknmt.github.io/StagePSA/wiki/#Comment%20detecter%20la%20domaine%20trimmée>`_ for more detail.
