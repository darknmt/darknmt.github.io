NURBS_Class module
==================

.. automodule:: NURBS_Class
    :members:
    :undoc-members:
    :show-inheritance:
