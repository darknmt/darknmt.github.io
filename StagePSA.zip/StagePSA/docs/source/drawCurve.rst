drawCurve module
================

.. automodule:: drawCurve
    :members:
    :undoc-members:
    :show-inheritance:
